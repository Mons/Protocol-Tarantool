#!/usr/bin/perl

{
	package # hide
		MyBuilder;
	
	sub _print {
		$_[1] =~ s{^(.+?)(#.+?|)(?:\n|\z)}{\e[$_[0]{__color};1m$1\e[35m$2\e[0m}s;
		goto &{ $_[0]->can('SUPER::_print') };
	}
	
	sub ok {
		$_[0]{__color} = $_[1] ? 32 : $_[0]->in_todo ? 33 : 31;
		goto &{ $_[0]->can('SUPER::ok') };
	}
}

use warnings;
use strict;
use utf8;
use open qw(:std :utf8);
use lib qw(lib ../lib);
use lib qw(blib/lib blib/arch ../blib/lib ../blib/arch);

use Test::More tests    => 151;
use Encode qw(decode encode);
use Devel::Hexdump 'xd';

BEGIN {
	if (-t STDOUT) {
	my $b = Test::More->builder;
	@MyBuilder::ISA = ( ref $b );
	bless $b, 'MyBuilder';
	warn Test::More->builder;
	}
}

=for rem
pass 'x1';
fail 'x2';
{
	local $TODO = "Testing";
	pass 'x3';
	fail 'x4';
}
__END__
=cut

BEGIN {
    my $builder = Test::More->builder;
    binmode $builder->output,         ":utf8";
    binmode $builder->failure_output, ":utf8";
    binmode $builder->todo_output,    ":utf8";

    use_ok 'Protocol::Tarantool', ':constant';
    use_ok 'File::Spec::Functions', 'catfile';
    use_ok 'File::Basename', 'dirname';
}

like TNT_INSERT,            qr{^\d+$}, 'TNT_INSERT';
like TNT_SELECT,            qr{^\d+$}, 'TNT_SELECT';
like TNT_UPDATE,            qr{^\d+$}, 'TNT_UPDATE';
like TNT_DELETE,            qr{^\d+$}, 'TNT_DELETE';
like TNT_CALL,              qr{^\d+$}, 'TNT_CALL';
like TNT_PING,              qr{^\d+$}, 'TNT_PING';

like TNT_FLAG_RETURN,       qr{^\d+$}, 'TNT_FLAG_RETURN';
like TNT_FLAG_ADD,          qr{^\d+$}, 'TNT_FLAG_ADD';
like TNT_FLAG_REPLACE,      qr{^\d+$}, 'TNT_FLAG_REPLACE';
like TNT_FLAG_BOX_QUIET,    qr{^\d+$}, 'TNT_FLAG_BOX_QUIET';
like TNT_FLAG_NOT_STORE,    qr{^\d+$}, 'TNT_FLAG_NOT_STORE';



use DR::Tarantool ();
use Protocol::Tarantool ();

#my @ops = [ [ int(rand 100), 'substr', int(rand 100), int(rand 100), "somestring"  ], map { [ int rand 100, $_, int rand 100, 'I' ] } qw(add and or xor set delete insert) ];
#push @ops, [ int(rand 100), 'substr', int(rand 100), int(rand 100), "somestring"  ];
#my $sbody = DR::Tarantool::_pkt_update( 15, 16, 17, [ 18 ], [ [ int(rand 100), 'substr', int(rand 100), int(rand 100), "somestring"  ], map { [ int rand 100, $_, int rand 100, 'I' ] } qw(add and or xor set delete insert) ]);

my @ops = map { [ int rand 100, $_, int rand 100, 'I' ] } qw(+ & | ^ = !),'#';
push @ops, [ int(rand 100), ':', int(rand 100), int(rand 100), "somestring"  ];
my $sbody = Protocol::Tarantool::update( 15, 16, 17, [ 18 ], \@ops);

#diag xd $sbody;

use uni::perl ':dumper';

my $seq;
sub w(;$){ $seq = $_[0] if @_; ++$seq; }

sub parse_packet {
	my $raw = shift;
	my @names = qw( set add and xor or str del ins );
	my %pk;
	( @pk{ qw(type len id) }, $raw) = unpack 'V3 a*', $raw;
	if ($pk{type} == TNT_SELECT) {
		( @pk{ qw( space index offset limit count ) }, $raw) = unpack 'V5 a*', $raw;
		for (1..$pk{count}) {
			my @tuple = unpack 'V/(w/a*) a*', $raw;
			$raw = pop @tuple;
			map $_ = "$_:s", @tuple;
			push @{ $pk{tuples} },\@tuple;
		}
	}
	elsif ($pk{type} == TNT_INSERT) {
		( @pk{ qw( space flags ) }, $raw) = unpack 'V2 a*', $raw;
		my @tuple = unpack 'V/(w/a*) a*', $raw;
		$raw = pop @tuple;
		map $_ = "$_:s", @tuple;
		$pk{tuple} = \@tuple;
	}
	elsif ($pk{type} == TNT_DELETE) {
		( @pk{ qw( space flags ) }, $raw) = unpack 'V2 a*', $raw;
		my @tuple = unpack 'V/(w/a*) a*', $raw;
		$raw = pop @tuple;
		map $_ = "$_:s", @tuple;
		$pk{tuple} = \@tuple;
	}
	elsif ($pk{type} == TNT_UPDATE) {
		( @pk{ qw( space flags ) }, $raw) = unpack 'V2 a*', $raw;
		my @tuple = unpack 'V/(w/a*) a*', $raw;
		$raw = pop @tuple;
		map $_ = "$_:s", @tuple;
		$pk{tuple} = \@tuple;
		my $count;
		($count,$raw) = unpack 'V a*', $raw;
		my @ops;
		for (1..$count) {
			my @op = unpack '(V C w/a*) a*',$raw;
			$raw = pop @op;
			
			if ($op[1] == 1 or $op[1] == 2 or $op[1] == 3 or $op[1] == 4 ) {
				($op[2]) = unpack 'V', $op[2];
			}
			elsif ($op[1] == 5) {
				push @op, unpack 'w/a* w/a* w/a*',pop @op;
				$op[$_] = unpack 'V', $op[$_] for 2,3;
				$op[4] .= ':s';
			}
			elsif( $op[1] == 6) {
				pop @op if @op == 3 and $op[2] eq '';
			}
			else {
				$op[2] .= ':s';
			}
			$op[1] = $names[$op[1]];
			push @ops, \@op;
		}
		$pk{ops} = \@ops;
	}
	elsif ($pk{type} == TNT_CALL) {
		( @pk{ qw( flags proc ) }, $raw) = unpack 'V w/a* a*', $raw;
		my @tuple = unpack 'V/(w/a*) a*', $raw;
		$raw = pop @tuple;
		map $_ = "$_:s", @tuple;
		$pk{tuple} = \@tuple;
	}
	$pk{trash} = $raw;
	return \%pk;
}

sub dmp($) {
	my $s = dumper $_[0];
	$s =~ s{\n$}{};
	$s;
}

use strict;

sub render($) {
	my $ref = shift;
	my $out;
	$out .= "{\n";
	for ( sort keys %$ref ) {
		if (!ref $ref->{$_}) {
			$out .= "\t$_ => ". (
				$ref->{$_} =~ /^\d+$/ ? $ref->{$_} :
				dmp($ref->{$_})
			). ",\n",
		}
	}
	for ( sort keys %$ref ) {
		if (ref $ref->{$_} eq 'ARRAY') {
			if (!@{ $ref->{$_} }) {
				$out .= "\t$_ => [],\n",
			}
			elsif (ref $ref->{$_}[0] eq 'ARRAY') {
				$out .= "\t$_ => [\n";
				for my $v ( @{ $ref->{$_} } ) {
					$out .= "\t\t[".join(', ',map { dmp($_) } @$v)."],\n",
				}
				$out .= "\t],\n";
			}
			else {
				$out .= "\t$_ => [\n";
				for my $v ( @{ $ref->{$_} } ) {
					$out .= "\t\t[".dmp($v)."],\n";
				}
				$out .= "\t],\n";
			}
			#$out .= "\t$_ => [". $ref->{$_} . ",\n",
		}
	}
	$out .= "}\n";
}

#diag dumper parse_packet(Protocol::Tarantool::select( 9, 8, 7, 6, 5, [ [4], [3] ] ));

use JSON::XS;
use lib::abs;
{
my $path = lib::abs::path('tests/select');
my $test = '000';
for (1, 0xff, 0xffffff, 0x7fffffff) {
	w($_);
	{
	my %s = (
		id => w,
		ns => w,
		idx => w,
		offset => w,
		limit => w,
		keys => [ [w],[w],["test"] ],
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } render \%s;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_select( $s{id}, $s{ns}, $s{idx}, $s{offset}, $s{limit}, $s{keys} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } render parse_packet($pkt);
	close $f;
	}
	
	{
	my %s = (
		id => w,
		ns => w,
		idx => w,
		offset => w,
		limit => w,
		keys => [ [pack V => w, "sometest" ],[ pack V => w, "anothertest" ] ],
	);
	my %as = (
		%s,
		keys => [ map { [ unpack('V', $_->[0]), @{$_}[ 1..$#$_ ] ] } @{ $s{keys} } ],
		format => 'Ip',
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%as;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_select( $s{id}, $s{ns}, $s{idx}, $s{offset}, $s{limit}, $s{keys} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
}
}
{
my $path = lib::abs::path('tests/delete');
my $test = '000';
for (1, 0xff, 0xffffff, 0x7fffffff) {
	w($_);
	{
	my %s = (
		id => w,
		ns => w,
		flags => w,
		key => [ w,w,"test" ],
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%s;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_delete( $s{id}, $s{ns}, $s{flags}, $s{key} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
	
	{
	my %s = (
		id => w,
		ns => w,
		flags => w,
		key => [ pack V => w, "sometest", "anothertest" ],
	);
	my %as = (
		%s,
		key => [ map { unpack('V', $_->[0]), @{$_}[ 1..$#$_ ] } $s{key} ],
		format => 'Ipu',
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%as;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_delete( $s{id}, $s{ns}, $s{flags}, $s{key} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
}
}

{
my $path = lib::abs::path('tests/insert');
my $test = '000';
for (1, 0xff, 0xffffff, 0x7fffffff) {
	w($_);
	{
	my %s = (
		id => w,
		ns => w,
		flags => w,
		key => [ w,w,"test" ],
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%s;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_insert( $s{id}, $s{ns}, $s{flags}, $s{key} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
	
	{
	my %s = (
		id => w,
		ns => w,
		flags => w,
		key => [ pack V => w, "sometest", "anothertest" ],
	);
	my %as = (
		%s,
		key => [ map { unpack('V', $_->[0]), @{$_}[ 1..$#$_ ] } $s{key} ],
		format => 'Ipu',
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%as;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_insert( $s{id}, $s{ns}, $s{flags}, $s{key} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
}
}

{
my $path = lib::abs::path('tests/lua');
my $test = '000';
for (1, 0xff, 0xffffff, 0x7fffffff) {
	w($_);
	{
	my %s = (
		id     => w,
		flags  => w,
		proc => sprintf('call%x',$_),
		args   => [ w,w,"test" ],
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%s;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_call_lua( $s{id}, $s{flags}, $s{proc}, $s{args} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
	
	{
	my %s = (
		id     => w,
		flags  => w,
		proc => sprintf('call%x',$_),
		args => [ pack V => w, "sometest", "anothertest" ],
	);
	my %as = (
		%s,
		args => [ map { unpack('V', $_->[0]), @{$_}[ 1..$#$_ ] } $s{args} ],
		format => 'Ipu',
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%as;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_call_lua( $s{id}, $s{flags}, $s{proc}, $s{args} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
}
}

our %UPDATE = (
	delete => '#',
	del    => '#',
	set    => '=',
	insert => '!',
	ins    => '!',
	add    => '+',
	sub    => '-',
	and    => '&',
	or     => '|',
	xor    => '^',
	substr => ':',
);

our %ROP = reverse %UPDATE;

{
my $path = lib::abs::path('tests/update');
my $test = '000';
for (1, 0xff, 0xffffff, 0x7fffffff) {
	w($_);
	{
	my %s = (
		id     => w,
		ns     => w,
		flags  => w,
		key => [ w,w,"test" ],
		'ops' => [ [ w, 'substr', w, w, "somestring"  ], ( map { [ w, $_, pack 'V',w ] } qw(add and or xor) ), ( map { [ w, $_, w ] } qw(set delete insert) ) ]
	);
	my %as = (
		%s,
		ops => [ map {
			my @a = @$_;
			exists $UPDATE{$a[1]} or die "No op $a[1]";
			if ($a[1] =~ m{^(add|and|or|xor)$}) {
				$a[2] = unpack 'V', $a[2],
			}
			$a[1] = $UPDATE{$a[1]};
			\@a;
		} @{ $s{ops} } ],
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%as;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_update( $s{id}, $s{ns}, $s{flags}, $s{key}, $s{ops} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
	
	if (0){
	my %s = (
		id     => w,
		flags  => w,
		proc => sprintf('call%x',$_),
		args => [ pack V => w, "sometest", "anothertest" ],
	);
	my %as = (
		%s,
		args => [ map { unpack('V', $_->[0]), @{$_}[ 1..$#$_ ] } $s{args} ],
		format => 'Ipu',
	);
	++$test;
	open my $f, '>:raw', "$path/$test.source";
	print { $f } dumper \%as;
	close $f;
	
	my $pkt = DR::Tarantool::_pkt_call_lua( $s{id}, $s{flags}, $s{proc}, $s{args} );
	
	open my $f, '>:raw', "$path/$test.binary";
	print { $f } $pkt;
	close $f;

	open my $f, '>:raw', "$path/$test.result";
	print { $f } dumper parse_packet($pkt);
	close $f;
	}
}
}


__END__
say render parse_packet(DR::Tarantool::_pkt_update( w, w, w, [ w, 'a', 'b', 'c', 'testing' ], [ [ w, 'substr', w, w, "somestring"  ], ( map { [ w, $_, pack 'V',w ] } qw(add and or xor) ), ( map { [ w, $_, w ] } qw(set delete insert) ) ]));
say render parse_packet(DR::Tarantool::_pkt_insert( w, w, w, [ w, 'a', 'b', 'c', 'testing' ] ));
say render parse_packet(DR::Tarantool::_pkt_delete( w, w, w, [ w, 'a', 'b', 'c', 'testing' ] ));
say render parse_packet(DR::Tarantool::_pkt_call_lua( w, w, 'procname', [ w, 'procarg', w ]));


__END__


my $LE = $] > 5.01 ? '<' : '';


# SELECT
diag "Testing select";
my $sbody = Protocol::Tarantool::select( 9, 8, 7, 6, 5, [ [4], [3] ] );
ok defined $sbody, '* select body';

my @a = unpack "( L$LE )*", $sbody;
is $a[0], TNT_SELECT, 'select type';
is $a[1], length($sbody) - 3 * 4, 'select - body length';
is $a[2], 9, 'select - request id';
is $a[3], 8, 'select - space no';
is $a[4], 7, 'select - index no';
is $a[5], 6, 'select - offset';
is $a[6], 5, 'select - limit';
is $a[7], 2, 'select - tuple count';
ok !eval { Protocol::Tarantool::select( 1, 2, 3, 4, 5, [ 6 ] ) }, 'select - keys format';
like $@ => qr{ARRAYREF of ARRAYREF}, 'select - error string';

# PING
diag "Testing ping";
$sbody = Protocol::Tarantool::ping( 11 );
ok defined $sbody, '* ping body';
@a = unpack "( L$LE )*", $sbody;
is $a[0], TNT_PING, 'ping type';
is $a[1], length($sbody) - 3 * 4, 'ping - body length';
is $a[2], 11, 'ping - request id';


# insert
diag "Testing insert";
$sbody = Protocol::Tarantool::insert( 12, 13, 14, [ 'a', 'b', 'c', 'd' ]);
ok defined $sbody, '* insert body';
@a = unpack "( L$LE )*", $sbody;
is $a[0], TNT_INSERT, 'insert type';
is $a[1], length($sbody) - 3 * 4, 'body length';
is $a[2], 12, 'request id';
is $a[3], 13, 'space no';
is $a[4], 14, 'flags';
is $a[5], 4,  'tuple size';
#diag xd $sbody;
#__END__

# delete
$sbody = Protocol::Tarantool::delete( 119, 120, 121, [ 122, 123 ] );
ok defined $sbody, '* delete body';
@a = unpack "( L$LE )*", $sbody;
is $a[0], TNT_DELETE, 'delete type';
is $a[1], length($sbody) - 3 * 4, 'body length';
is $a[2], 119, 'request id';

is $a[3], 120, 'space no';

if (TNT_DELETE == 20) {
    ok 1, '# skipped old delete code';
    is $a[4], 2,  'tuple size';
} else {
    is $a[4], 121, 'flags';  # libtarantool ignores flags
    is $a[5], 2,  'tuple size';
}

# call
$sbody = Protocol::Tarantool::lua( 124, 125, 'tproc', [ 126, 127 ]);
ok defined $sbody, '* call body';
@a = unpack "L$LE L$LE L$LE L$LE w/Z* L$LE L$LE", $sbody;
is $a[0], TNT_CALL, 'call type';
is $a[1], length($sbody) - 3 * 4, 'body length';
is $a[2], 124, 'request id';
is $a[3], 125, 'flags';
is $a[4], 'tproc',  'proc name';
is $a[5], 2, 'tuple size';

# update
diag "Testing update";
my @ops = map { [ int rand 100, $_, int rand 100, 'I' ] }
    qw(+ & | ^ = !),'#';
push @ops, [ int(rand 100), ':', int(rand 100), int(rand 100), "somestring"  ];

$sbody = Protocol::Tarantool::update( 15, 16, 17, [ 18 ], \@ops);
ok defined $sbody, '* update body';
@a = unpack "( L$LE )*", $sbody;
is $a[0], TNT_UPDATE, 'update type';
is $a[1], length($sbody) - 3 * 4, 'update - body length';
is $a[2], 15, 'update - request id';
is $a[3], 16, 'update - space no';
is $a[4], 17, 'update - flags';
is $a[5], 1,  'update - tuple size';

diag "Testing lua";
$sbody = Protocol::Tarantool::lua( 124, 125, 'tproc', [  ]);

# parser
ok !eval { Protocol::Tarantool::response( undef ) }, '* parser: undef';
my $res = Protocol::Tarantool::response( '' );
diag explain $res;
isa_ok $res => 'HASH', 'empty input';
like $res->{errstr}, qr{too short}, 'error message';
is $res->{status}, 'buffer', 'status';

my $data;
for (TNT_INSERT, TNT_UPDATE, TNT_SELECT, TNT_DELETE, TNT_CALL, TNT_PING) {
    my $msg = "test message";
    $data = pack "L$LE L$LE L$LE L$LE Z*",
        $_, 5 + length $msg, $_ + 100, 0x0101, $msg;
    $res = Protocol::Tarantool::response( $data );
    diag explain $res;
    isa_ok $res => 'HASH', 'well input ' . $_;
    is $res->{id}, $_ + 100, 'request id';
    is $res->{type}, $_, 'request type';

    unless($res->{type} == TNT_PING) {
        is $res->{status}, 'error', "status $_";
        is $res->{code}, 0x101, 'code';
        is $res->{errstr}, $msg, 'errstr';
    }
}

my $cfg_dir = catfile dirname(__FILE__), 'test-data';
ok -d $cfg_dir, 'directory with test data';
my @bins = glob catfile $cfg_dir, '*.bin';

for my $bin (@bins) {
    my ($type, $err, $status) =
        $bin =~ /(?>0*)?(\d+?)-0*(\d+)-(\w+)\.bin$/;
    next unless defined $bin;
    next unless $type;
    ok -r $bin, "$bin is readable";

    ok open(my $fh, '<:raw', $bin), "open $bin";
    my $pkt;
    { local $/; $pkt = <$fh>; }
    ok $pkt, "response body was read from $bin";
    diag xd $pkt;

    my $res = Protocol::Tarantool::response( $pkt );
    diag explain $res;
    SKIP: {
        skip 'legacy delete packet', 4 if $type == 20 and TNT_DELETE != 20;
        my $ok = 1;
        $ok &&= is $res->{status}, $status, $bin.' - status';
        $ok &&= is $res->{type}, $type, $bin.' - type';
        $ok &&= is $res->{code}, $err, $bin.' - error code';
        $ok &&= ok ( !($res->{code} xor $res->{errstr}), 'errstr' );
        $ok or diag explain $res;
    }
}

